package com.example.privateblock.listener;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.data.BlockData;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class ExplosionListener implements Listener {

    private final PrivateBlockPlugin plugin;

    public ExplosionListener(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent event) {
        for (Location loc : event.blockList()) {
            BlockData data = plugin.getBlockManager().getBlock(loc);
            if (data != null) {
                plugin.getBlockManager().damageBlock(data, 1);
            }
        }
    }
}
