package com.example.privateblock.manager;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.config.BlockConfig;
import com.example.privateblock.data.BlockData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class BlockManager {

    private final PrivateBlockPlugin plugin;
    private final Map<Location, BlockData> blocks = new HashMap<>();

    public BlockManager(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
        loadAll();
    }

    public void placeBlock(Player player, Location loc, BlockConfig.BlockType type) {
        BlockData data = new BlockData(loc, player.getUniqueId(), type.id, type.maxHp, type.maxHp);
        blocks.put(loc, data);
        plugin.getHologramManager().createOrUpdate(data);
    }

    public BlockData getBlock(Location loc) {
        return blocks.get(loc);
    }

    public void removeBlock(Location loc) {
        BlockData data = blocks.remove(loc);
        if (data != null) {
            plugin.getHologramManager().remove(data);
        }
    }

    public void damageBlock(BlockData data, int amount) {
        if (data == null) return;
        data.hp -= amount;
        if (data.hp <= 0) {
            destroyBlock(data);
        } else {
            plugin.getHologramManager().createOrUpdate(data);
        }
    }

    private void destroyBlock(BlockData data) {
        plugin.getHologramManager().remove(data);
        data.location.getBlock().setType(org.bukkit.Material.AIR);
        blocks.remove(data.location);
    }

    public void saveAll() {
    }

    private void loadAll() {
    }
}
