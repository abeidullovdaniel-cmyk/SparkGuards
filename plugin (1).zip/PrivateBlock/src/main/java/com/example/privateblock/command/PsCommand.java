package com.example.privateblock.command;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.config.BlockConfig;
import com.example.privateblock.data.BlockData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class PsCommand implements CommandExecutor, TabCompleter {

    private final PrivateBlockPlugin plugin;

    public PsCommand(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§c/ps <add|remove|info|give|reload>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "add" -> {
                if (!(sender instanceof Player player)) return true;
                if (args.length < 2) {
                    player.sendMessage("§c/ps add <ник>");
                    return true;
                }
                BlockData data = getLookingBlock(player);
                if (data == null) {
                    player.sendMessage("§cСмотрите на блок привата.");
                    return true;
                }
                if (!data.owner.equals(player.getUniqueId())) {
                    player.sendMessage("§cТолько владелец может добавлять участников.");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    player.sendMessage("§cИгрок не найден.");
                    return true;
                }
                data.members.add(target.getUniqueId());
                player.sendMessage("§aИгрок добавлен.");
            }
            case "remove" -> {
                if (!(sender instanceof Player player)) return true;
                if (args.length < 2) {
                    player.sendMessage("§c/ps remove <ник>");
                    return true;
                }
                BlockData data = getLookingBlock(player);
                if (data == null) {
                    player.sendMessage("§cСмотрите на блок привата.");
                    return true;
                }
                if (!data.owner.equals(player.getUniqueId())) {
                    player.sendMessage("§cТолько владелец может удалять участников.");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    player.sendMessage("§cИгрок не найден.");
                    return true;
                }
                data.members.remove(target.getUniqueId());
                player.sendMessage("§aИгрок удалён.");
            }
            case "info" -> {
                if (!(sender instanceof Player player)) return true;
                BlockData data = getLookingBlock(player);
                if (data == null) {
                    player.sendMessage("§cСмотрите на блок привата.");
                    return true;
                }
                player.sendMessage("§6Владелец: §f" + Bukkit.getOfflinePlayer(data.owner).getName());
                player.sendMessage("§6HP: §f" + data.hp + "/" + data.maxHp);
                player.sendMessage("§6Участники: §f" + data.members.size());
            }
            case "give" -> {
                if (!sender.hasPermission("ps.admin")) {
                    sender.sendMessage("§cНет прав.");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage("§c/ps give <игрок> <тип>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                BlockConfig.BlockType type = plugin.getBlockConfig().getType(args[2]);
                if (target == null || type == null) {
                    sender.sendMessage("§cИгрок или тип не найден.");
                    return true;
                }
                target.getInventory().addItem(new org.bukkit.ItemStack(type.material));
                sender.sendMessage("§aВыдано.");
            }
            case "reload" -> {
                if (!sender.hasPermission("ps.admin")) {
                    sender.sendMessage("§cНет прав.");
                    return true;
                }
                plugin.reloadConfig();
                plugin.getBlockConfig().load();
                sender.sendMessage("§aКонфиг перезагружен.");
            }
            default -> sender.sendMessage("§cНеизвестная подкоманда.");
        }
        return true;
    }

    private BlockData getLookingBlock(Player player) {
        Location loc = player.getTargetBlockExact(5) != null ?
                player.getTargetBlockExact(5).getLocation() : null;
        if (loc == null) return null;
        return plugin.getBlockManager().getBlock(loc);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) {
            list.add("add");
            list.add("remove");
            list.add("info");
            if (sender.hasPermission("ps.admin")) {
                list.add("give");
                list.add("reload");
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            list.addAll(plugin.getBlockConfig().getBlockTypes().keySet());
        }
        return list;
    }
}
