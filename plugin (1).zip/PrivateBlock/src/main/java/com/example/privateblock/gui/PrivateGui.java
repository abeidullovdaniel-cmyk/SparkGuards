package com.example.privateblock.gui;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.data.BlockData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PrivateGui implements InventoryHolder, Listener {

    private final PrivateBlockPlugin plugin;
    private final BlockData data;
    private final Player player;
    private final Inventory inventory;

    public PrivateGui(PrivateBlockPlugin plugin, BlockData data, Player player) {
        this.plugin = plugin;
        this.data = data;
        this.player = player;

        String title = plugin.getConfig().getString("gui.title", "&8Управление приватом");
        this.inventory = Bukkit.createInventory(this, 27,
                LegacyComponentSerializer.legacyAmpersand().deserialize(title));
        build();
    }

    public void open() {
        player.openInventory(inventory);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void build() {
        int repairSlot = plugin.getConfig().getInt("gui.repair-slot", 10);
        Material repairMat = Material.matchMaterial(plugin.getConfig().getString("gui.repair-material", "ANVIL"));
        String repairName = plugin.getConfig().getString("gui.repair-name", "&aПочинить приват");
        List<String> repairLore = plugin.getConfig().getStringList("gui.repair-lore");

        int costAmount = plugin.getConfig().getInt("gui.repair-cost-amount", 5);
        String costMatName = plugin.getConfig().getString("gui.repair-cost-material", "IRON_INGOT");
        long cooldown = plugin.getConfig().getInt("gui.repair-cooldown-seconds", 300);

        List<String> lore = new ArrayList<>();
        for (String line : repairLore) {
            lore.add(line.replace("%hp%", String.valueOf(data.hp))
                    .replace("%max_hp%", String.valueOf(data.maxHp))
                    .replace("%price%", String.valueOf(costAmount))
                    .replace("%item%", costMatName)
                    .replace("%cooldown%", String.valueOf(cooldown)));
        }

        inventory.setItem(repairSlot, createItem(repairMat != null ? repairMat : Material.ANVIL,
                repairName, lore));

        int borderSlot = plugin.getConfig().getInt("gui.border-slot", 12);
        Material borderMat = Material.matchMaterial(plugin.getConfig().getString("gui.border-material", "ENDER_EYE"));
        String borderName = plugin.getConfig().getString("gui.border-name", "&dПоказать границы");
        List<String> borderLore = plugin.getConfig().getStringList("gui.border-lore");
        inventory.setItem(borderSlot, createItem(borderMat != null ? borderMat : Material.ENDER_EYE,
                borderName, borderLore));

        int toggleSlot = plugin.getConfig().getInt("gui.toggle-slot", 14);
        Material toggleMat = Material.matchMaterial(plugin.getConfig().getString("gui.toggle-material", "NAME_TAG"));
        String toggleName = plugin.getConfig().getString("gui.toggle-name", "&eСкрыть/Показать голограмму");
        List<String> toggleLore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList("gui.toggle-lore")) {
            toggleLore.add(line.replace("%state%", data.hologramVisible ? "Видима" : "Скрыта"));
        }
        inventory.setItem(toggleSlot, createItem(toggleMat != null ? toggleMat : Material.NAME_TAG,
                toggleName, toggleLore));

        int infoSlot = plugin.getConfig().getInt("gui.info-slot", 16);
        Material infoMat = Material.matchMaterial(plugin.getConfig().getString("gui.info-material", "PLAYER_HEAD"));
        String infoName = plugin.getConfig().getString("gui.info-name", "&fУчастники и инфо");
        List<String> infoLore = new ArrayList<>();
        String ownerName = Bukkit.getOfflinePlayer(data.owner).getName();
        if (ownerName == null) ownerName = "Unknown";
        for (String line : plugin.getConfig().getStringList("gui.info-lore")) {
            infoLore.add(line.replace("%owner%", ownerName)
                    .replace("%members%", String.valueOf(data.members.size()))
                    .replace("%radius_x%", String.valueOf(plugin.getBlockConfig().getType(data.typeId).radiusX))
                    .replace("%radius_y%", String.valueOf(plugin.getBlockConfig().getType(data.typeId).radiusY))
                    .replace("%radius_z%", String.valueOf(plugin.getBlockConfig().getType(data.typeId).radiusZ)));
        }
        inventory.setItem(infoSlot, createItem(infoMat != null ? infoMat : Material.PLAYER_HEAD,
                infoName, infoLore));

        if (player.getUniqueId().equals(data.owner)) {
            int takeSlot = plugin.getConfig().getInt("gui.take-slot", 22);
            Material takeMat = Material.matchMaterial(plugin.getConfig().getString("gui.take-material", "BARRIER"));
            String takeName = plugin.getConfig().getString("gui.take-name", "&cЗабрать приват");
            List<String> takeLore = plugin.getConfig().getStringList("gui.take-lore");
            inventory.setItem(takeSlot, createItem(takeMat != null ? takeMat : Material.BARRIER,
                    takeName, takeLore));
        }
    }

    private ItemStack createItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(LegacyComponentSerializer.legacyAmpersand().deserialize(name));
            if (lore != null && !lore.isEmpty()) {
                List<Component> components = new ArrayList<>();
                for (String line : lore) {
                    components.add(LegacyComponentSerializer.legacyAmpersand().deserialize(line));
                }
                meta.lore(components);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof PrivateGui)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getView().getTopInventory()) return;

        int slot = event.getRawSlot();
        int repairSlot = plugin.getConfig().getInt("gui.repair-slot", 10);
        int borderSlot = plugin.getConfig().getInt("gui.border-slot", 12);
        int toggleSlot = plugin.getConfig().getInt("gui.toggle-slot", 14);
        int takeSlot = plugin.getConfig().getInt("gui.take-slot", 22);

        if (slot == repairSlot) {
            long now = System.currentTimeMillis();
            long cooldownMs = plugin.getConfig().getInt("gui.repair-cooldown-seconds", 300) * 1000L;
            if (now - data.lastRepairTime < cooldownMs) {
                long remaining = (cooldownMs - (now - data.lastRepairTime)) / 1000;
                player.sendMessage("§cКД починки: " + remaining + " сек.");
                return;
            }

            Material costMat = Material.matchMaterial(plugin.getConfig().getString("gui.repair-cost-material", "IRON_INGOT"));
            int costAmount = plugin.getConfig().getInt("gui.repair-cost-amount", 5);
            if (costMat == null || !player.getInventory().contains(costMat, costAmount)) {
                player.sendMessage("§cНедостаточно ресурсов.");
                return;
            }

            player.getInventory().removeItem(new ItemStack(costMat, costAmount));
            int heal = plugin.getConfig().getInt("gui.repair-heal-amount", 5);
            data.hp = Math.min(data.maxHp, data.hp + heal);
            data.lastRepairTime = now;
            plugin.getHologramManager().createOrUpdate(data);
            player.sendMessage("§aПриват починен.");
            player.closeInventory();
        } else if (slot == borderSlot) {
            player.sendMessage("§dГраницы подсвечены (заглушка для частиц).");
            player.closeInventory();
        } else if (slot == toggleSlot) {
            data.hologramVisible = !data.hologramVisible;
            if (data.hologramVisible) {
                plugin.getHologramManager().createOrUpdate(data);
            } else {
                plugin.getHologramManager().remove(data);
            }
            player.sendMessage("§eГолограмма: " + (data.hologramVisible ? "видима" : "скрыта"));
            player.closeInventory();
        } else if (slot == takeSlot && player.getUniqueId().equals(data.owner)) {
            plugin.getBlockManager().removeBlock(data.location);
            data.location.getBlock().setType(Material.AIR);
            player.sendMessage("§cПриват забран.");
            player.closeInventory();
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof PrivateGui) {
            event.setCancelled(true);
        }
    }
}
