package com.example.privateblock.data;

import org.bukkit.Location;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class BlockData {
    public final Location location;
    public final UUID owner;
    public final String typeId;
    public int hp;
    public final int maxHp;
    public final Set<UUID> members = new HashSet<>();
    public boolean hologramVisible = true;
    public UUID hologramEntityId;
    public long lastRepairTime = 0;

    public BlockData(Location location, UUID owner, String typeId, int hp, int maxHp) {
        this.location = location;
        this.owner = owner;
        this.typeId = typeId;
        this.hp = hp;
        this.maxHp = maxHp;
    }
}
