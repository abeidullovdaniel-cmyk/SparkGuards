package com.example.privateblock;

import com.example.privateblock.command.PsCommand;
import com.example.privateblock.config.BlockConfig;
import com.example.privateblock.listener.BlockListener;
import com.example.privateblock.listener.ExplosionListener;
import com.example.privateblock.manager.BlockManager;
import com.example.privateblock.manager.HologramManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class PrivateBlockPlugin extends JavaPlugin {

    private static PrivateBlockPlugin instance;
    private BlockConfig blockConfig;
    private BlockManager blockManager;
    private HologramManager hologramManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.blockConfig = new BlockConfig(this);
        this.blockConfig.load();

        this.hologramManager = new HologramManager(this);
        this.blockManager = new BlockManager(this);

        getServer().getPluginManager().registerEvents(new BlockListener(this), this);
        getServer().getPluginManager().registerEvents(new ExplosionListener(this), this);

        PsCommand psCommand = new PsCommand(this);
        getCommand("ps").setExecutor(psCommand);
        getCommand("ps").setTabCompleter(psCommand);

        getLogger().info("PrivateBlock enabled.");
    }

    @Override
    public void onDisable() {
        if (blockManager != null) {
            blockManager.saveAll();
        }
        getLogger().info("PrivateBlock disabled.");
    }

    public static PrivateBlockPlugin getInstance() {
        return instance;
    }

    public BlockConfig getBlockConfig() {
        return blockConfig;
    }

    public BlockManager getBlockManager() {
        return blockManager;
    }

    public HologramManager getHologramManager() {
        return hologramManager;
    }
}
