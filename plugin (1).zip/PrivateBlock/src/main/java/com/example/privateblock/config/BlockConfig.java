package com.example.privateblock.config;

import com.example.privateblock.PrivateBlockPlugin;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlockConfig {

    private final PrivateBlockPlugin plugin;
    private final Map<String, BlockType> blockTypes = new HashMap<>();

    public BlockConfig(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        blockTypes.clear();
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("blocks");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            ConfigurationSection s = section.getConfigurationSection(key);
            if (s == null) continue;

            Material material = Material.matchMaterial(s.getString("material", "STONE"));
            if (material == null) material = Material.STONE;

            BlockType type = new BlockType(
                    key,
                    material,
                    s.getString("name", key),
                    s.getStringList("lore"),
                    s.getInt("radius-x", 5),
                    s.getInt("radius-y", 3),
                    s.getInt("radius-z", 5),
                    s.getInt("max-hp", 10),
                    s.getBoolean("lightning-on-place", false)
            );
            blockTypes.put(key, type);
        }
    }

    public BlockType getType(String key) {
        return blockTypes.get(key);
    }

    public Map<String, BlockType> getBlockTypes() {
        return blockTypes;
    }

    public static class BlockType {
        public final String id;
        public final Material material;
        public final String name;
        public final List<String> lore;
        public final int radiusX, radiusY, radiusZ;
        public final int maxHp;
        public final boolean lightningOnPlace;

        public BlockType(String id, Material material, String name, List<String> lore,
                         int radiusX, int radiusY, int radiusZ, int maxHp, boolean lightningOnPlace) {
            this.id = id;
            this.material = material;
            this.name = name;
            this.lore = lore;
            this.radiusX = radiusX;
            this.radiusY = radiusY;
            this.radiusZ = radiusZ;
            this.maxHp = maxHp;
            this.lightningOnPlace = lightningOnPlace;
        }
    }
}
