package com.example.privateblock.manager;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.data.BlockData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;

public class HologramManager {

    private final PrivateBlockPlugin plugin;

    public HologramManager(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
    }

    public void createOrUpdate(BlockData data) {
        remove(data);
        if (!data.hologramVisible) return;

        String format = plugin.getConfig().getString("hologram.format", "&6%owner% &7| &c%hp%&7/&c%max_hp%");
        String ownerName = Bukkit.getOfflinePlayer(data.owner).getName();
        if (ownerName == null) ownerName = "Unknown";

        String text = format
                .replace("%owner%", ownerName)
                .replace("%hp%", String.valueOf(data.hp))
                .replace("%max_hp%", String.valueOf(data.maxHp));

        Component component = LegacyComponentSerializer.legacyAmpersand().deserialize(text);
        double offset = plugin.getConfig().getDouble("hologram.height-offset", 1.2);
        Location loc = data.location.clone().add(0.5, offset, 0.5);

        TextDisplay display = loc.getWorld().spawn(loc, TextDisplay.class, entity -> {
            entity.text(component);
            entity.setBillboard(Display.Billboard.CENTER);
            entity.setSeeThrough(true);
            entity.setDefaultBackground(false);
            entity.setViewRange(0.5f);
        });

        data.hologramEntityId = display.getUniqueId();
    }

    public void remove(BlockData data) {
        if (data.hologramEntityId != null) {
            Entity entity = Bukkit.getEntity(data.hologramEntityId);
            if (entity != null) entity.remove();
            data.hologramEntityId = null;
        }
    }
}
