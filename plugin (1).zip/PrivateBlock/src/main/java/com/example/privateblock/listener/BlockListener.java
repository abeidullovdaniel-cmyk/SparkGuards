package com.example.privateblock.listener;

import com.example.privateblock.PrivateBlockPlugin;
import com.example.privateblock.config.BlockConfig;
import com.example.privateblock.data.BlockData;
import com.example.privateblock.gui.PrivateGui;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class BlockListener implements Listener {

    private final PrivateBlockPlugin plugin;

    public BlockListener(PrivateBlockPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        BlockConfig.BlockType type = null;
        for (BlockConfig.BlockType t : plugin.getBlockConfig().getBlockTypes().values()) {
            if (t.material == event.getBlock().getType()) {
                type = t;
                break;
            }
        }
        if (type == null) return;

        plugin.getBlockManager().placeBlock(player, event.getBlock().getLocation(), type);

        if (type.lightningOnPlace) {
            event.getBlock().getWorld().strikeLightningEffect(event.getBlock().getLocation());
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getClickedBlock() == null) return;

        Location loc = event.getClickedBlock().getLocation();
        BlockData data = plugin.getBlockManager().getBlock(loc);
        if (data == null) return;

        Player player = event.getPlayer();
        if (!data.owner.equals(player.getUniqueId()) && !data.members.contains(player.getUniqueId())) {
            event.setCancelled(true);
            player.sendMessage("§cВы не владелец этого привата.");
            return;
        }

        event.setCancelled(true);
        new PrivateGui(plugin, data, player).open();
    }
}
